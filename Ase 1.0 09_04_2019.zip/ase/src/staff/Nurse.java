package staff;

public class Nurse {
	private String name;
	private int age;
	private String hospital;
	
	public Nurse(String name,int age,String hospital) {
	this.name=name;
	this.age=age;
	this.hospital=hospital;
	}
}
