package Clients;

import java.io.IOException;

import Objects.Appointment;

public class MainReceptionist {

	public static void main(String[] args) {
		Receptionist rp = new Receptionist(15455503,"Dulce Rodrigues","localhost",8080);
		rp.connect();
		rp.start();
		String s = "Test";
		Appointment a = new Appointment(s);
	}
}


