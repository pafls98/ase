package GUI;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Clients.Receptionist;
import Objects.Appointment;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class RGUI extends JFrame {

	private JPanel contentPane;
	private Receptionist r;
	private JTextField textField;

	public RGUI(Receptionist r) {
		this.r=r;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle(r.getNAME() + " - " + r.getID());
		
		JButton btnResponse = new JButton("Response");
		btnResponse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Appointment a = new Appointment("Test sucessful");
				try {
					r.sendMessage(a);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnResponse.setBounds(150, 68, 116, 23);
		contentPane.add(btnResponse);
		
		textField = new JTextField();
		textField.setBounds(150, 102, 116, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		setVisible(true);
	}
	
	public void update(String s) {
		textField.setText(s);
	}
}

