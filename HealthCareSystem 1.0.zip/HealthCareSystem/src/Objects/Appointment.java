package Objects;

import java.io.Serializable;

public class Appointment implements Serializable {

	private static final long serialVersionUID = 141445054250096202L;
	
	private String m;

	public Appointment(String m) {
		this.m=m;
	}

	public String getM() {
		return m;
	}
}
