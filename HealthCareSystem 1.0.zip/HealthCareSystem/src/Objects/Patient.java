package Objects;

public class Patient {

}
