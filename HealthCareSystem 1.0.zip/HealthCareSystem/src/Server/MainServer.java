package Server;

public class MainServer {

	public static void main(String[] args) {
		Server s = new Server(8080);
		s.connect();
	}
}
