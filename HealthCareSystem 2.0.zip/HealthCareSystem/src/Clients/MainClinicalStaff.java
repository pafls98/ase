package Clients;

public class MainClinicalStaff {

	public static void main(String[] args) {
		ClinicalStaff c = new ClinicalStaff(15455503,"Dulce Rodrigues","localhost",8080);
		c.connect();
		c.start();
	}
}
