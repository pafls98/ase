package Clients;

import java.io.IOException;


public class MainReceptionist {

	public static void main(String[] args) throws IOException {
		Receptionist rp = new Receptionist(15455503,"Dulce Rodrigues","localhost",8080);
		rp.connect();
		rp.start();
	}
}


