package Objects;

public class Building {

}
