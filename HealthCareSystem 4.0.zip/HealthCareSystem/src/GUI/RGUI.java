package GUI;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Clients.Receptionist;
import Objects.Search;
import Objects.SearchResponse;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.border.BevelBorder;

public class RGUI extends JFrame {

	private JPanel contentPane;
	private Receptionist r;
	private JTextField searchText;

	//JList
	private JList<String> list;
	private DefaultListModel<String> model;

	public RGUI(Receptionist r) {
		this.r=r;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 590, 490);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		searchText = new JTextField();
		searchText.setForeground(Color.BLACK);
		searchText.setBounds(109, 11, 207, 23);
		contentPane.add(searchText);
		searchText.setColumns(10);

		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(10, 11, 89, 23);
		contentPane.add(btnSearch);
		setTitle(r.getNAME() + " - " + r.getID());
		setVisible(true);

		//JList
		model = new DefaultListModel<>();
		list = new JList<>(model);
		list.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.GRAY, null, null, null));
		list.setBounds(10, 45, 306, 395);
		contentPane.add(list);

		//Code here buttons
		
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//model.clear();
				int id = Integer.parseInt(searchText.getText());
				Search s = new Search(id);
				try {
					r.sendMessage(s);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
	}
	//Code here functions

	public void addSR(SearchResponse rs) {
		String s = (rs.getDate() + " " + rs.getCs() + " " + rs.getC() + " " + rs.getD() + " " + rs.getT() + " " + rs.isUpdated());
		model.addElement(s);
	}
}

