package Objects;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import Clients.ClinicalStaff;

public class Patient implements Serializable {


	private static final long serialVersionUID = -4406916726841967484L;

	private boolean alive;
	private boolean risk;
	private boolean mentalIlness;
	private String name;
	private int id;
	private boolean selfHarm;
	private String lastAppointment;
	private Treatment lastTreatment;
	private Drug lastDrug;


	private List <Allergy> alergies;
	private List <ClinicalStaff> responsables;
	private List <Record> records;
	private List <Appointment> appointment;

	public Patient(boolean alive, boolean risk, boolean mentalIlness, String name, int id, boolean selfHarm,
			String lastAppointment, Treatment lastTreatment, Drug lastDrug) {
		this.alive = alive;
		this.risk = risk;
		this.mentalIlness = mentalIlness;
		this.name = name;
		this.id = id;
		this.selfHarm = selfHarm;
		this.lastAppointment = lastAppointment;
		this.lastTreatment = lastTreatment;
		this.lastDrug = lastDrug;
		alergies = new ArrayList<Allergy>();
		responsables = new ArrayList<ClinicalStaff>();
		records= new ArrayList<Record>();
		appointment = new ArrayList<Appointment>();
	}

	public void addAllergy(Allergy a) {
		alergies.add(a);
	}

	public void addClinicalStaff(ClinicalStaff cs) {
		responsables.add(cs);
	}

	public void addRecord(Record r) {
		records.add(r);
	}

	public void addAppointment(Appointment a) {
		appointment.add(a);
	}

	public boolean isAlive() {
		return alive;
	}

	public void setAlive(boolean alive) {
		this.alive = alive;
	}

	public boolean isRisk() {
		return risk;
	}

	public void setRisk(boolean risk) {
		this.risk = risk;
	}

	public boolean isMentalIlness() {
		return mentalIlness;
	}

	public void setMentalIlness(boolean mentalIlness) {
		this.mentalIlness = mentalIlness;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isSelfHarm() {
		return selfHarm;
	}

	public void setSelfHarm(boolean selfHarm) {
		this.selfHarm = selfHarm;
	}

	public String getLastAppointment() {
		return lastAppointment;
	}

	public void setLastAppointment(String lastAppointment) {
		this.lastAppointment = lastAppointment;
	}

	public Treatment getLastTreatment() {
		return lastTreatment;
	}

	public void setLastTreatment(Treatment lastTreatment) {
		this.lastTreatment = lastTreatment;
	}

	public Drug getLastDrug() {
		return lastDrug;
	}

	public void setLastDrug(Drug lastDrug) {
		this.lastDrug = lastDrug;
	}

	public List<Allergy> getAlergies() {
		return alergies;
	}

	public void setAlergies(List<Allergy> alergies) {
		this.alergies = alergies;
	}

	public List<ClinicalStaff> getResponsables() {
		return responsables;
	}

	public void setResponsables(List<ClinicalStaff> responsables) {
		this.responsables = responsables;
	}

	public List<Record> getRecord() {
		return records;
	}

	public void setRecord(List<Record> record) {
		this.records = records;
	}

	public List<Appointment> getAppointment() {
		return appointment;
	}

	public void setAppointment(List<Appointment> appointment) {
		this.appointment = appointment;
	}
}