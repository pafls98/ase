package Objects;

import java.io.Serializable;

import Clients.ClinicalStaff;

public class SearchResponse implements Serializable{

	private static final long serialVersionUID = 7650952864080730743L;
	
	private String date;
	private Drug d;
	private Treatment t;
	private String c;
	private ClinicalStaff cs;
	private boolean updated;
	
	public SearchResponse(String date, Drug d, Treatment t, String c, ClinicalStaff cs, boolean updated) {
		this.date = date;
		this.d = d;
		this.t = t;
		this.c = c;
		this.cs = cs;
		this.updated = updated;
	}
		
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Drug getD() {
		return d;
	}
	public void setD(Drug d) {
		this.d = d;
	}
	public Treatment getT() {
		return t;
	}
	public void setT(Treatment t) {
		this.t = t;
	}
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	public ClinicalStaff getCs() {
		return cs;
	}
	public void setCs(ClinicalStaff cs) {
		this.cs = cs;
	}
	public boolean isUpdated() {
		return updated;
	}
	public void setUpdated(boolean updated) {
		this.updated = updated;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	

}
