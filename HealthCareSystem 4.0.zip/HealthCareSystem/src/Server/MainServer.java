package Server;

import java.util.ArrayList;
import java.util.List;

import Clients.ClinicalStaff;
import Objects.Allergy;
import Objects.Appointment;
import Objects.Building;
import Objects.Drug;
import Objects.Patient;
import Objects.Record;
import Objects.Treatment;

public class MainServer {

	public static void main(String[] args) {
		//		Server s = new Server(8080);
		//		s.connect();
		//Create one patient structure start
		List <Building> bl = new ArrayList<>();
		Building b = new Building("Central Hospital", 1);
		List <Patient> pl = new ArrayList<>();
		Treatment t = new Treatment("Medicated");
		List <Allergy> sel = new ArrayList<>();
		Allergy a1 = new Allergy("fatigue");
		Allergy a2 = new Allergy("nausea");
		Allergy a3 = new Allergy("lemon");
		sel.add(a1);
		sel.add(a2);
		sel.add(a3);
		Drug d = new Drug("Xanax",sel);
		List<Drug> dl = new ArrayList<>();
		Patient p = new Patient(true, true, true, "Julio de Matos", 1, true, "09/07/1998", t, d);
		List<Allergy> pal = new ArrayList<>();
		Allergy p1 = new Allergy("lemon");
		p.addAllergy(p1);
		ClinicalStaff cs1 = new ClinicalStaff(15766703,"Francisca Tavares","localhost",8080);
		p.addClinicalStaff(cs1);
		Appointment ap1 = new Appointment(true, "09/07/1998", p, b, cs1, 20);
		p.addAppointment(ap1);
		Record r = new Record("Head against the wall", "09/07/1998", d, t, "Very agressive", "Talked very loud", "Medication should solve the problem", true, cs1);
		p.addRecord(r);
		//Create one patient structure end

		Server s = new Server(8080);
		s.addBuilding(b);
		s.addDrug(d);
		s.addPatient(p);
		s.connect();
	}
}