package GUI;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Clients.Receptionist;
import Objects.Search;
import Objects.SearchResponse;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.border.BevelBorder;

public class RGUI extends JFrame {

	private JPanel contentPane;
	private Receptionist r;
	private JTextField searchText;

	//JList
	private JList<String> list;
	private DefaultListModel<String> model;

	public RGUI(Receptionist r) {
		this.r=r;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 590, 490);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		searchText = new JTextField();
		searchText.setForeground(Color.BLACK);
		searchText.setBounds(10, 11, 455, 23);
		contentPane.add(searchText);
		searchText.setColumns(10);

		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(475, 11, 89, 23);
		contentPane.add(btnSearch);
		setTitle(r.getNAME() + " - " + r.getID());
		setVisible(true);

		//JList
		model = new DefaultListModel<>();
		list = new JList<>(model);
		list.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.GRAY, null, null, null));
		list.setBounds(10, 45, 554, 119);
		contentPane.add(list);
		
		//Code here buttons
		
		JButton btnGetRecord = new JButton("Get Record");
		btnGetRecord.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int selectedRecord = list.getSelectedIndex();
				String record = model.getElementAt(selectedRecord);
				RSEL rsel = new RSEL(record);
				rsel.go();
			}
		});
		btnGetRecord.setBounds(215, 175, 145, 23);
		contentPane.add(btnGetRecord);

		

		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//model.clear();
				int id = Integer.parseInt(searchText.getText());
				Search s = new Search(id);
				try {
					r.sendMessage(s);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
	}
	//Code here functions

	public void addSR(SearchResponse rs) {
		if(rs.isUpdated()==true) {
			String s = (rs.getPatient() + " : " + rs.getDate() + " : " + rs.getCs().getNAME() + " : " + rs.getC() + " : " + rs.getT().getName() + " : " +  rs.getD().getName() + " : " + "Updated");
			model.addElement(s);
		}
		if(rs.isUpdated()==false) {
			String s = (rs.getPatient() + " @ " + rs.getDate() + " @ " + rs.getCs().getNAME() + " @ " + rs.getC() + " @ " + rs.getT().getName() + " @ " + rs.getD().getName() + " @ " + "Not Updated");
			model.addElement(s);
		}
	}
}
