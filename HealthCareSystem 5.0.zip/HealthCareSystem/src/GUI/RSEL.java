package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Clients.ClinicalStaff;
import Clients.Receptionist;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.SystemColor;
import javax.swing.UIManager;

public class RSEL extends JFrame {

	private JPanel contentPane;
	private String s;
	private JTextField dataField;
	private JTextField doctorField;
	private JTextField diaField;
	private JTextField tField;
	private JTextField drugField;
	private JTextField upField;

	public RSEL(String s) {
		this.s=s;
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.BLACK, null, null, null));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Record Information");
		
		dataField = new JTextField();
		dataField.setEditable(false);
		dataField.setBounds(86, 11, 312, 20);
		contentPane.add(dataField);
		dataField.setColumns(10);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(10, 11, 66, 20);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblData = new JLabel("Date");
		lblData.setBounds(0, 0, 66, 20);
		panel.add(lblData);
		lblData.setHorizontalAlignment(SwingConstants.CENTER);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(10, 54, 66, 20);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblClinicalStaff = new JLabel("Doctor");
		lblClinicalStaff.setBounds(0, 0, 66, 20);
		panel_1.add(lblClinicalStaff);
		lblClinicalStaff.setHorizontalAlignment(SwingConstants.CENTER);
		
		doctorField = new JTextField();
		doctorField.setEditable(false);
		doctorField.setColumns(10);
		doctorField.setBounds(86, 54, 312, 20);
		contentPane.add(doctorField);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(10, 98, 66, 20);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblDiagnostic = new JLabel("Diagnostic");
		lblDiagnostic.setBounds(0, 0, 66, 20);
		panel_2.add(lblDiagnostic);
		lblDiagnostic.setHorizontalAlignment(SwingConstants.CENTER);
		
		diaField = new JTextField();
		diaField.setEditable(false);
		diaField.setColumns(10);
		diaField.setBounds(86, 98, 312, 20);
		contentPane.add(diaField);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.LIGHT_GRAY);
		panel_3.setBounds(10, 138, 66, 20);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblTreatment = new JLabel("Treatment");
		lblTreatment.setBounds(0, 0, 66, 20);
		panel_3.add(lblTreatment);
		lblTreatment.setHorizontalAlignment(SwingConstants.CENTER);
		
		tField = new JTextField();
		tField.setEditable(false);
		tField.setColumns(10);
		tField.setBounds(86, 138, 312, 20);
		contentPane.add(tField);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.LIGHT_GRAY);
		panel_4.setBounds(10, 180, 66, 20);
		contentPane.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblDrugUsed = new JLabel("Drug Used");
		lblDrugUsed.setBounds(0, 0, 66, 20);
		panel_4.add(lblDrugUsed);
		lblDrugUsed.setHorizontalAlignment(SwingConstants.CENTER);
		
		drugField = new JTextField();
		drugField.setEditable(false);
		drugField.setColumns(10);
		drugField.setBounds(86, 180, 312, 20);
		contentPane.add(drugField);
		
		upField = new JTextField();
		upField.setEditable(false);
		upField.setBounds(312, 230, 86, 20);
		contentPane.add(upField);
		upField.setColumns(10);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(Color.LIGHT_GRAY);
		panel_5.setBounds(227, 230, 66, 20);
		contentPane.add(panel_5);
		panel_5.setLayout(null);
		
		JLabel lblUpdated = new JLabel("Updated?");
		lblUpdated.setBounds(0, 0, 66, 20);
		panel_5.add(lblUpdated);
		lblUpdated.setHorizontalAlignment(SwingConstants.CENTER);
	}
	
	public void go() {
		String[] record = s.split(":");
		setTitle("Patient: " + record[0]);
		dataField.setText(record[1]);
		doctorField.setText(record[2]);
		diaField.setText(record[3]);
		tField.setText(record[4]);
		drugField.setText(record[5]);
		upField.setText(record[6]);
		setVisible(true);
	}
}
