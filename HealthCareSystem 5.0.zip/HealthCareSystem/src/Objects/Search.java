package Objects;

import java.io.Serializable;

public class Search implements Serializable {
	
	private static final long serialVersionUID = -3689564910125552997L;
	private int id;

	public Search(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	

}
