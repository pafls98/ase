package Clients;

import java.io.IOException;

public class MainMRecordsStaff {

	public static void main(String[] args) throws IOException {
		MRecordsStaff mrs = new MRecordsStaff(15455503,"Ana Rosa","localhost",8080);
		mrs.connect();
		mrs.start();
	}
}
