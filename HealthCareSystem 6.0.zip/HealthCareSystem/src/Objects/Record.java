package Objects;

import java.io.Serializable;

import Clients.ClinicalStaff;

public class Record implements Serializable {


	private static final long serialVersionUID = -5894304126802692147L;
	private String selfHarmIncident;
	private String date;
	private Drug d; //Medicine
	private Treatment treatment; //Treatment
	private String condition; // Diagnostic
	private String details;
	private String comments; //Coments
	private ClinicalStaff cs;
	private boolean updated;

	public Record(String selfHarmIncident, String date, Drug d,Treatment treatment,
			String condition, String comments,
			boolean updated,ClinicalStaff cs) {
		this.selfHarmIncident = selfHarmIncident;
		this.date = date;
		this.d = d;
		this.treatment = treatment;
		this.condition = condition;
		this.details = details;
		this.comments = comments;
		this.updated = updated;
		this.cs=cs;
	}

	public String getSelfHarmIncident() {
		return selfHarmIncident;
	}

	public void setSelfHarmIncident(String selfHarmIncident) {
		this.selfHarmIncident = selfHarmIncident;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Drug getD() {
		return d;
	}

	public void setD(Drug d) {
		this.d = d;
	}

	public Treatment getTreatment() {
		return treatment;
	}

	public void setTreatment(Treatment treatment) {
		this.treatment = treatment;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public boolean isUpdated() {
		return updated;
	}

	public void setUpdated(boolean updated) {
		this.updated = updated;
	}

	public ClinicalStaff getCs() {
		return cs;
	}

	public void setCs(ClinicalStaff cs) {
		this.cs = cs;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}
}
