package Objects;

import java.io.Serializable;

import Clients.ClinicalStaff;

public class Appointment implements Serializable {

	private static final long serialVersionUID = 90578610841818720L;
	private boolean attended;
	private int id;
	private String date;
	private Patient p;
	private Building b;
	private ClinicalStaff cs;
	private int waitingTime;
	private String hours;

	public Appointment(boolean attended, String date, Patient p, Building b, ClinicalStaff cs,int id,String hours) {
		this.attended = attended;
		this.date = date;
		this.p = p;
		this.b = b;
		this.cs = cs;
		this.id=id;
		this.hours=hours;
	}

	public String getHours() {
		return hours;
	}





	public void setHours(String hours) {
		this.hours = hours;
	}





	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public boolean isAttended() {
		return attended;
	}

	public void setAttended(boolean attended) {
		this.attended = attended;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Patient getP() {
		return p;
	}

	public void setP(Patient p) {
		this.p = p;
	}

	public Building getB() {
		return b;
	}

	public void setB(Building b) {
		this.b = b;
	}

	public ClinicalStaff getCs() {
		return cs;
	}

	public void setCs(ClinicalStaff cs) {
		this.cs = cs;
	}

	public int getWaitingTime() {
		return waitingTime;
	}

	public void setWaitingTime(int waitingTime) {
		this.waitingTime = waitingTime;
	}
}
