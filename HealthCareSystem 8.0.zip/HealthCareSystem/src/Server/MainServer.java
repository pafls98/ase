package Server;

import java.util.ArrayList;
import java.util.List;

import Clients.ClinicalStaff;
import Objects.Allergy;
import Objects.Appointment;
import Objects.Building;
import Objects.Drug;
import Objects.Patient;
import Objects.Record;
import Objects.Treatment;

public class MainServer {

	public static void main(String[] args) {

		//Buildings
		Building b = new Building("Central Hospital", 1);
		
		//Treatments
		Treatment t = new Treatment("Medicated");
		
		//List of drug side effects
		List <Allergy> sel = new ArrayList<>();
		Allergy a1 = new Allergy("fatigue");
		Allergy a2 = new Allergy("nausea");
		Allergy a3 = new Allergy("lemon");
		sel.add(a1);
		sel.add(a2);
		sel.add(a3);
		
		//Drugs
		Drug d = new Drug("Xanax",sel);
		
		//Patients
		Patient p = new Patient(true, true, true, "Julio de Matos", 1, true, "09/07/1998", t, d);
		
		//Allergies of patients
		Allergy p1 = new Allergy("nuts");
		p.addAllergy(p1);
		
		//ClinicalStaff that works with created Patients
		ClinicalStaff cs1 = new ClinicalStaff(15766703,"Francisca Tavares","localhost",8080);
		p.addClinicalStaff(cs1);
		
		//Appointments
		Appointment ap1 = new Appointment(true, "09/07/1998", p, b, cs1,1,"2:30");
		p.addAppointment(ap1);
		
		//Records
		Record r = new Record("Had knife cuts in the arms", "09/07/1998", d, t, "Patient thinks that he was being followed", "Medication should solve the problem", true, cs1);
		p.addRecord(r);
		
		
		Server s = new Server(8080);
		
		//Add to Server
		s.addBuilding(b);
		s.addDrug(d);
		s.addPatient(p);
		s.connect();
		
	}
}