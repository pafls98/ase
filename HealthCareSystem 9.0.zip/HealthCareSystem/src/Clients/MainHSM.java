package Clients;

import java.io.IOException;


public class MainHSM {

	public static void main(String[] args) throws IOException {
		HSM hsm = new HSM(15446543,"Tiago Amaro","localhost",8080);
		hsm.connect();
		hsm.start();
	}
}
