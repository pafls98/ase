package Objects;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Building implements Serializable {

	private static final long serialVersionUID = -5294513269685135320L;
	private String name;
	private int id;
	private List <Integer> perDay;
	private int patientPerDay;
	private int patientPerMonth;
	private int precribedDrugs;

	public Building(String name, int id) {
		this.name = name;
		this.id = id;
		perDay =  new ArrayList<Integer>();
		patientPerDay=0;
		patientPerMonth=0;
		precribedDrugs=0;
	}
	
	public void addPerDay(int a) {
		perDay.add(a);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<Integer> getPerDay() {
		return perDay;
	}

	public void setPerDay(List<Integer> perDay) {
		this.perDay = perDay;
	}

	public int getPatientPerDay() {
		return patientPerDay;
	}

	public void setPatientPerDay(int patientPerDay) {
		this.patientPerDay = patientPerDay;
	}

	public int getPatientPerMonth() {
		return patientPerMonth;
	}

	public void setPatientPerMonth(int patientPerMonth) {
		this.patientPerMonth = patientPerMonth;
	}

	public int getPrecribedDrugs() {
		return precribedDrugs;
	}

	public void setPrecribedDrugs(int precribedDrugs) {
		this.precribedDrugs = precribedDrugs;
	}	
}