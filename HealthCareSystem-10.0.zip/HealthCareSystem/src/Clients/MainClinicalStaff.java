package Clients;

import java.io.IOException;

public class MainClinicalStaff {

	public static void main(String[] args) {
		ClinicalStaff cs = new ClinicalStaff(15766703,"Francisca Tavares","localhost",8080);
		cs.getGui().go();
		cs.connect();
		cs.start();
		
		String x = "get Lists";
		try {
			cs.sendMessage(x);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
