package Handler;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

import Objects.Appointment;
import Objects.Attend;
import Objects.Drug;
import Objects.Patient;
import Objects.Record;
import Objects.Search;
import Objects.SearchResponse;
import Server.Server;


public class ClientHandler extends Thread{

	private Server server;
	private Socket socket;
	private ObjectOutputStream out;
	private ObjectInputStream in;


	public ClientHandler (Server server, Socket socket) {
		this.server=server;
		this.socket=socket;
		try {
			out = new ObjectOutputStream(socket.getOutputStream());
			in = new ObjectInputStream(socket.getInputStream());			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendMessage (Object o) throws IOException {
		out.writeObject(o);
	}

	public Object readMessage() throws ClassNotFoundException, IOException {
		return in.readObject();
	}


	@Override
	public void run() {
		try {
			while(!interrupted()) {		
				Object message = readMessage();
				
				//Search for records by id
				if(message instanceof Search) {
					int id = ((Search) message).getId();
					System.out.println("aqui " + ((Search) message).isRecord());
					for (Patient p : server.getPatientsList()) {

						if (((Search) message).isConsultation()) {
							if(p.getId()==id) {
									SearchResponse sr = new SearchResponse(p);
									sr.setConsultation(true);
									sendMessage(sr);
							}
						}
						if (((Search) message).iscS()) {
							for (Appointment a : p.getAppointment()) {
								if (a.getCs().equals(((Search) message).getName())) {
									SearchResponse sr = new SearchResponse (p.getName(),a.isAttended(),a.getDate(),a.getB(),a.getCs(),a.getId(),a.getHours());
									sr.setSearch(true);
									sendMessage(sr);
								}
							}
						}
						
						if(((Search) message).isRecord()) {
							System.out.println("atum");
							SearchResponse sr = new SearchResponse(p);
							sr.setRecord(true);
							sendMessage(sr);
						} else {
						if(p.getId()==id) { 
							String name = p.getName();
							for(Record r : p.getRecord()) {
								SearchResponse sr = new SearchResponse(r.getDate(), r.getD(), r.getTreatment(), r.getCondition(), r.getCs(), r.isUpdated(),name);
								sendMessage(sr);
								System.out.println("Search sucessful");
							}
						}
					}
					}
				}
				//Make appointments by id
				if(message instanceof Appointment) {
					Appointment a = (Appointment) message;
					int id = a.getId();
					for (Patient p : server.getPatientsList()) {
						if(p.getId()==id) {
							for(Appointment ap : p.getAppointment()) {
								p.addAppointment(a);
								System.out.println("Appointment added");
							}
						}
					}
					//Patient attended appointment
				}if(message instanceof Attend) {
					int id = ((Attend) message).getId();
					for (Patient p : server.getPatientsList()) {
						if(p.getId()==id) {
							for(Appointment ap : p.getAppointment()) {
								ap.setAttended(true);
								System.out.println("Patient attended appointment");
							}
						}
					}
				}
				if(message instanceof Record) {
					Record a = (Record) message;
					int id = a.getiD();
					for (Patient p : server.getPatientsList()) {
						if(p.getId()==id) {
							p.addRecord(a);
						}
					}
				}
				if(message instanceof String) {
					List <Drug> drugsList = server.getDrugsList();
					sendMessage(drugsList);
				}
			}
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
}