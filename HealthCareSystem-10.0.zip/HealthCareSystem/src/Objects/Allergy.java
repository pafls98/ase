package Objects;

import java.io.Serializable;

public class Allergy implements Serializable {


	private static final long serialVersionUID = -6714222524194948738L;

	private String name;

	public Allergy(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
