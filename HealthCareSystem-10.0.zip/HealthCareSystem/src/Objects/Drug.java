package Objects;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Drug implements Serializable{
	

	private static final long serialVersionUID = 2946215461493858088L;
	private String name;
	private List<Allergy> sideEffects = new ArrayList<>();
	
	public Drug(String name,  List<Allergy> sideEffects) {
		this.name = name;
		this.sideEffects = sideEffects;
	}
	public Drug(String name) {
		this.name = name;
	}
	public void addSideEffect(Allergy a) {
		sideEffects.add(a);
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public List<Allergy> getSideEffects() {
		return sideEffects;
	}
	
	public void setSideEffects(List<Allergy> sideEffects) {
		this.sideEffects = sideEffects;
	}
}