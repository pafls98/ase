package Clients;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import GUI.HSMGUI;
import Objects.MReport;
import Objects.WReport;


public class HSM extends Thread {



	private int id;
	private String name;
	private Socket socket;
	private String ip;
	private int port;
	private ObjectOutputStream out;
	private ObjectInputStream in;
	private HSMGUI gui;

	public HSM (int id,String name,String ip,int port) {
		this.id=id;
		this.name=name;
		this.port=port;
		this.ip=ip;
		this.gui = new HSMGUI(this);
	}

	public void connect() {
		try {
			socket = new Socket(ip,port);
			out = new ObjectOutputStream(socket.getOutputStream());	
			in = new ObjectInputStream(socket.getInputStream());				
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int getID() {
		return id;
	}

	public String getNAME() {
		return name;
	}

	public void sendMessage (Object o) throws IOException {
		out.writeObject(o);
	}

	public Object readMessage() throws ClassNotFoundException, IOException {
		return in.readObject();
	}

	@Override
	public void run() {
		try {
			while(!interrupted()) {
				Object message = readMessage();
				if(message instanceof WReport) {
					WReport wr = (WReport) message;
					String s = ("");
					s = s + (wr.getC() + "[]" + wr.getD() + "[]" + wr.getNp());
					System.out.println(s);
					//Fun��o do Rafa
				}
			}
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
}