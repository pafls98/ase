package GUI;


import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Clients.HSM;
import Clients.Receptionist;
import Objects.MReport;
import Objects.WReport;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class HSMGUI extends JFrame {

	private JPanel contentPane;

	private HSM h;
	
	private String mr;
	private String wr;

	public HSMGUI(HSM h) {
		this.h=h;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 306, 133);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnWeeklyReport = new JButton("Report");
		btnWeeklyReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WReport w = new WReport("", "",0);
				try {
					h.sendMessage(w);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		btnWeeklyReport.setBounds(70, 29, 157, 33);
		contentPane.add(btnWeeklyReport);
		setTitle(h.getNAME() + " - " + h.getID());
		setVisible(true);
	}
}

