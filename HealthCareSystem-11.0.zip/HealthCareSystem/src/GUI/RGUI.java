package GUI;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Clients.Receptionist;
import Objects.Appointment;
import Objects.Attend;
import Objects.Search;
import Objects.SearchResponse;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.border.BevelBorder;

public class RGUI extends JFrame {

	private JPanel contentPane;
	private Receptionist r;
	private JTextField searchText;
	private int appID = 1;

	//JList
	private JList<String> list;
	private DefaultListModel<String> model;
	private JTextField dia;
	private JTextField mes;
	private JTextField ano;
	private JTextField idd;
	private JLabel lblName;
	private JTextField name;
	private JLabel lblHours;
	private JTextField horas;
	private JLabel label_1;
	private JTextField min;
	private JLabel lblBuilding;
	private JTextField buil;
	private JLabel lblDoctor;
	private JTextField doc;

	public RGUI(Receptionist r) {
		this.r=r;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 590, 490);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		searchText = new JTextField();
		searchText.setForeground(Color.BLACK);
		searchText.setBounds(10, 11, 455, 23);
		contentPane.add(searchText);
		searchText.setColumns(10);

		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(475, 11, 89, 23);
		contentPane.add(btnSearch);
		setTitle(r.getNAME() + " - " + r.getID());
		

		//JList
		model = new DefaultListModel<>();
		list = new JList<>(model);
		list.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.GRAY, null, null, null));
		list.setBounds(10, 45, 554, 119);
		contentPane.add(list);



		JButton btnGetRecord = new JButton("Get Record");
		btnGetRecord.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int selectedRecord = list.getSelectedIndex();
				String record = model.getElementAt(selectedRecord);
				System.out.println(record);
				RSEL rsel = new RSEL(record);
				rsel.go();
			}
		});
		btnGetRecord.setBounds(215, 175, 145, 23);
		contentPane.add(btnGetRecord);
		
		dia = new JTextField();
		dia.setBounds(46, 238, 27, 20);
		contentPane.add(dia);
		dia.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("/");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(73, 241, 12, 14);
		contentPane.add(lblNewLabel);
		
		mes = new JTextField();
		mes.setColumns(10);
		mes.setBounds(83, 238, 27, 20);
		contentPane.add(mes);
		
		JLabel label = new JLabel("/");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(110, 241, 12, 14);
		contentPane.add(label);
		
		ano = new JTextField();
		ano.setColumns(10);
		ano.setBounds(120, 238, 89, 20);
		contentPane.add(ano);
		
		JLabel lblId = new JLabel("ID");
		lblId.setHorizontalAlignment(SwingConstants.CENTER);
		lblId.setBounds(219, 241, 34, 14);
		contentPane.add(lblId);
		
		idd = new JTextField();
		idd.setBounds(249, 238, 315, 20);
		contentPane.add(idd);
		idd.setColumns(10);
		
		lblName = new JLabel("Name");
		lblName.setBounds(8, 291, 37, 14);
		contentPane.add(lblName);
		
		name = new JTextField();
		name.setColumns(10);
		name.setBounds(46, 288, 518, 20);
		contentPane.add(name);
		
		lblHours = new JLabel("Hours");
		lblHours.setHorizontalAlignment(SwingConstants.CENTER);
		lblHours.setBounds(5, 342, 34, 14);
		contentPane.add(lblHours);
		
		horas = new JTextField();
		horas.setColumns(10);
		horas.setBounds(46, 339, 27, 20);
		contentPane.add(horas);
		
		label_1 = new JLabel(":");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setBounds(73, 342, 12, 14);
		contentPane.add(label_1);
		
		min = new JTextField();
		min.setColumns(10);
		min.setBounds(83, 339, 27, 20);
		contentPane.add(min);
		
		lblBuilding = new JLabel("Building");
		lblBuilding.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuilding.setBounds(120, 342, 46, 14);
		contentPane.add(lblBuilding);
		
		buil = new JTextField();
		buil.setBounds(176, 339, 388, 20);
		contentPane.add(buil);
		buil.setColumns(10);
		
		lblDoctor = new JLabel("Doctor");
		lblDoctor.setHorizontalAlignment(SwingConstants.CENTER);
		lblDoctor.setBounds(6, 385, 39, 14);
		contentPane.add(lblDoctor);
		
		doc = new JTextField();
		doc.setBounds(46, 382, 518, 20);
		contentPane.add(doc);
		doc.setColumns(10);
		
		JButton btnMakeAppointment = new JButton("Make Appointment");
		btnMakeAppointment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println(appID);
				String date = (dia.getText()+"/"+mes.getText()+"/"+ano.getText());
				String building = buil.getText();
				int id = Integer.parseInt(idd.getText());
				boolean attended = false;
				String doctor = doc.getText();
				String hours = (horas.getText()+"/"+min.getText());
				Appointment a = new Appointment (attended,date,building,doctor,id,hours);
				try {
					r.sendMessage(a);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		btnMakeAppointment.setBounds(83, 413, 145, 23);
		contentPane.add(btnMakeAppointment);
		
		JLabel lblDate = new JLabel("Date");
		lblDate.setBounds(10, 241, 27, 14);
		contentPane.add(lblDate);
		
		JButton btnAttended = new JButton("Attended");
		btnAttended.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int id = Integer.parseInt(idd.getText());
				Attend a = new Attend(id);
				try {
					r.sendMessage(a);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		btnAttended.setBounds(353, 413, 145, 23);
		contentPane.add(btnAttended);
		setVisible(true);

		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//model.clear();
				int id = Integer.parseInt(searchText.getText());
				Search s = new Search(id);
				try {
					r.sendMessage(s);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void addSR(SearchResponse rs) {
		if(rs.isUpdated()==true) {
			String s = (rs.getPatient() + " : " + rs.getDate() + " : " + rs.getCs().getNAME() + " : " + rs.getC() + " : " + rs.getT().getName() + " : " +  rs.getD().getName() + " : " + "Updated");
			model.addElement(s);
		}
		if(rs.isUpdated()==false) {
			String s = (rs.getPatient() + " @ " + rs.getDate() + " @ " + rs.getCs().getNAME() + " @ " + rs.getC() + " @ " + rs.getT().getName() + " @ " + rs.getD().getName() + " @ " + "Not Updated");
			model.addElement(s);
		}
	}
}
