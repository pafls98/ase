package Objects;

import java.io.Serializable;

public class Attend implements Serializable{

	private static final long serialVersionUID = 6838585868360684594L;
	private int id;


	public Attend( int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}		
}
