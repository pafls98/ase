package Objects;

import java.io.Serializable;

public class Treatment implements Serializable {
	
	private static final long serialVersionUID = 4814655449339646605L;
	
	private String name;

	public Treatment(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}