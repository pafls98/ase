package Clients;

public class MainClinicalStaff {

	public static void main(String[] args) {
		ClinicalStaff cs = new ClinicalStaff(15766703,"Francisca Tavares","localhost",8080);
		cs.connect();
		cs.start();
	}
}
