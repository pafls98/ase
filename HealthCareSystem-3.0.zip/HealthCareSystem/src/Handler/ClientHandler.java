package Handler;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

import Server.Server;


public class ClientHandler extends Thread{

	private Server server;
	private Socket socket;
	private ObjectOutputStream out;
	private ObjectInputStream in;


	public ClientHandler (Server server, Socket socket) {
		this.server=server;
		this.socket=socket;
		try {
			out = new ObjectOutputStream(socket.getOutputStream());
			in = new ObjectInputStream(socket.getInputStream());			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendMessage (Object o) throws IOException {
		out.writeObject(o);
	}

	public Object readMessage() throws ClassNotFoundException, IOException {
		return in.readObject();
	}


	@Override
	public void run() {
		try {
			while(!interrupted()) {		
				Object message = readMessage();
				if(message instanceof Object) {
					//Code here~
					System.out.println(message);
				}
			}
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
}