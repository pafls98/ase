package Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import Objects.Building;
import Objects.Patient;
import Handler.ClientHandler;

public class Server {
	private int port;
	private ServerSocket serverSocket;
	private List<Patient> patientsList;
	private List<Building> buildingsList;


	public Server(int port) {
		this.port=port;
	}

	public List<Patient> getPatientsList() {
		return patientsList;
	}

	public List<Building> getBuildingsList() {
		return buildingsList;
	}

	public void setPatientsList(List<Patient> patientsList) {
		this.patientsList = patientsList;
	}

	public void setBuildingsList(List<Building> buildingsList) {
		this.buildingsList = buildingsList;
	}

	public void connect() {
		try {
			patientsList=new ArrayList<Patient>();
			buildingsList=new ArrayList<Building>();
			serverSocket = new ServerSocket(port);
			System.out.println("Server is running");
			while(true) {
				Socket clientSocket = serverSocket.accept();
				System.out.println("A new client has connected");
				ClientHandler ch = new ClientHandler (this, clientSocket);
				ch.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

