package Clients;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;


import GUI.RGUI;
import Objects.SearchResponse;



public class Receptionist extends Thread {

	private int id;
	private String name;
	private Socket socket;
	private String ip;
	private int port;
	private ObjectOutputStream out;
	private ObjectInputStream in;
	private RGUI gui;

	public Receptionist (int id,String name,String ip,int port) {
		this.id=id;
		this.name=name;
		this.port=port;
		this.ip=ip;
		this.gui = new RGUI(this);
	}

	/**
	 * Establishes the connection to the server.
	 */
	public void connect() {
		try {
			socket = new Socket(ip,port);
			out = new ObjectOutputStream(socket.getOutputStream());	
			in = new ObjectInputStream(socket.getInputStream());				
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int getID() {
		return id;
	}

	public String getNAME() {
		return name;
	}

	public void sendMessage (Object o) throws IOException {
		out.writeObject(o);
	}

	public Object readMessage() throws ClassNotFoundException, IOException {
		return in.readObject();
	}

	@Override
	public void run() {
		try {
			while(!interrupted()) {
				Object message = readMessage();
				if(message instanceof SearchResponse) {
					SearchResponse sr = (SearchResponse) message;
					gui.addSR(sr);
				}	
			}
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}
}