package Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import Clients.ClinicalStaff;
import Objects.Building;
import Objects.Drug;
import Objects.Patient;
import Handler.ClientHandler;

public class Server {
	private int port;
	private ServerSocket serverSocket;
	private List<Patient> patientsList;
	private List<Building> buildingsList;
	private List <Drug> drugsList;
	private List <ClinicalStaff> clinicalStaffList;
	

	public Server(int port) {
		this.port = port;
		patientsList=new ArrayList<Patient>();
		buildingsList=new ArrayList<Building>();
		drugsList=new ArrayList<Drug>();
		clinicalStaffList= new ArrayList<ClinicalStaff>();
	}

	public List<Patient> getPatientsList() {
		return patientsList;
	}

	public List<Building> getBuildingsList() {
		return buildingsList;
	}

	public void setPatientsList(List<Patient> patientsList) {
		this.patientsList = patientsList;
	}

	public void setBuildingsList(List<Building> buildingsList) {
		this.buildingsList = buildingsList;
	}

	public List<Drug> getDrugsList() {
		return drugsList;
	}

	public void setDrugsList(List<Drug> drugsList) {
		this.drugsList = drugsList;
	}
	
	public void addPatient(Patient p) {
		patientsList.add(p);
	}
	public void addClinicalStaff(ClinicalStaff cs) {
		clinicalStaffList.add(cs);
	}
	
	public void addDrug(Drug d) {
		drugsList.add(d);
	}
	
	public void addBuilding(Building b) {
		buildingsList.add(b);
	}

	/**
	 * Creates the server and initiates a Client Handler for each client in order to establish the connection.
	 */
	public void connect() {
		try {
			serverSocket = new ServerSocket(port);
			System.out.println("Server is running");
			while(true) {
				Socket clientSocket = serverSocket.accept();
				System.out.println("A new client has connected");
				ClientHandler ch = new ClientHandler (this, clientSocket);
				ch.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public List <ClinicalStaff> getClinicalStaffList() {
		return clinicalStaffList;
	}

	public void setClinicalStaffList(List <ClinicalStaff> clinicalStaffList) {
		this.clinicalStaffList = clinicalStaffList;
	}
}


