package Clients;

import java.io.IOException;


public class MainReceptionist {

	public static void main(String[] args) throws IOException {
			go();
	}
	
	public static void go () {Receptionist r = new Receptionist(15455503,"Dulce Rodrigues","localhost",8080);
	r.connect();
	r.start();
		}
}
