package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import Clients.ClinicalStaff;
import Clients.Receptionist;
import Objects.Record;
import Objects.Search;
import Objects.SearchResponse;

import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import javax.swing.JInternalFrame;

public class CSGUI extends JFrame {
	private JList<String> list;
	private DefaultListModel<String> model;
	private JPanel contentPane;
	private ClinicalStaff c;
	private JTextField textField;
	private JTextField textField_1;
	private SearchResponse sr;
	private boolean isPat = false;

	public CSGUI(ClinicalStaff c) {
		this.c=c;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 512, 333);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 496, 294);
		contentPane.add(panel);
		panel.setLayout(null);

		model = new DefaultListModel<>();



		list = new JList(model);

		panel.add(list);

		JScrollPane scrollPane = new JScrollPane(list);
		scrollPane.setBounds(10, 66, 324, 161);
		panel.add(scrollPane);



		JButton btnGetAppointments = new JButton("Get Appointments");
		btnGetAppointments.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Search s = new Search (c.getNAME(), true);
				try {
					c.sendMessage(s);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnGetAppointments.setBounds(344, 63, 119, 23);
		panel.add(btnGetAppointments);

		JButton btnGetAllPatients = new JButton("Get all patients");
		btnGetAllPatients.setBounds(344, 99, 119, 23);
		panel.add(btnGetAllPatients);

		JLabel lblName = new JLabel("Name:");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblName.setBounds(10, 22, 44, 23);
		panel.add(lblName);

		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(50, 24, 119, 20);
		panel.add(textField);
		textField.setColumns(10);
		textField.setText(c.getNAME());

		JLabel lblId = new JLabel("ID:");
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblId.setBounds(203, 27, 46, 14);
		panel.add(lblId);

		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setBounds(223, 24, 111, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		textField_1.setText(String.valueOf(c.getID()));

		JButton btnGoToConsultation = new JButton("Go to Consultation");
		btnGoToConsultation.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String[] eu =model.elementAt(list.getSelectedIndex()).split(" : ");

				Search ii = new Search (Integer.parseInt(eu[6]));
				ii.setConsultation(true);

				try {
					c.sendMessage(ii);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btnGoToConsultation.setBounds(344, 133, 119, 23);
		btnGoToConsultation.setVisible(false);

		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnGoToConsultation.setVisible(true);

				//int id = Integer.parseInt(eu[6]);

			}
		});

		panel.add(btnGoToConsultation);
		
		JButton btnNewButton = new JButton("Get Record");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String[] eu =model.elementAt(list.getSelectedIndex()).split(" : ");

				Search ii = new Search (Integer.parseInt(eu[6]));
				ii.setRecord(true);
				try {
					c.sendMessage(ii);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		btnNewButton.setBounds(344, 167, 119, 23);
		panel.add(btnNewButton);
		setTitle(c.getNAME() + " - " + c.getID());
	}
	public void addSR(SearchResponse rs) {
		this.sr=rs;
		if(sr.isConsultation()) {
			RSEL2 rsel2 = new RSEL2(sr.getP().getRecord().get(sr.getP().getRecord().size()-1),c);
			rsel2.go();
			model.clear();
		}
		if (sr.isSearch()) {
			System.out.println("picha");
			String s = (rs.getPatient()+ " : " + rs.isAttended() + " : " + rs.getDate() + " : " + rs.getHours()+ " : " + rs.getB()+ " : " + rs.getCs2() + " : " +  rs.getId());
			model.addElement(s);
			}
		if(sr.isRecord()) {
			Record r = sr.getP().getRecord().get(sr.getP().getRecord().size()-1);
			String x = r.getDate() + " : " + r.getCondition() + " : " + r.getTreatment().getName() + " : " + r.getD().getName() +  " : Updated";
			RSEL3 n = new RSEL3 (x);
			n.go();
		}
		
		}
	public void go() {
		setVisible(true);
	}
}
