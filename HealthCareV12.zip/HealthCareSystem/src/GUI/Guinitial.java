package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Clients.MainClinicalStaff;
import Clients.MainHSM;
import Clients.MainReceptionist;
import Clients.Receptionist;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.JLabel;

public class Guinitial extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		go();
	}

	/**
	 * Create the frame.
	 */public static void go() {
		 EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						Guinitial frame = new Guinitial();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
	 }
	public Guinitial() throws IOException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 420, 217);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Receptionist");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				MainReceptionist rec = new MainReceptionist ();
				rec.go();
			}
		});
		btnNewButton.setBounds(31, 123, 100, 29);
		contentPane.add(btnNewButton);
		
		JButton btnClinicalStaff = new JButton("Clinical Staff");
		btnClinicalStaff.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MainClinicalStaff cs = new MainClinicalStaff ();
				cs.go();
			}
		});
		btnClinicalStaff.setBounds(157, 123, 100, 29);
		contentPane.add(btnClinicalStaff);
		
		JButton btnHsm = new JButton("HSM");
		btnHsm.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MainHSM hsm = new MainHSM();
				hsm.go();
			}
		});
		btnHsm.setBounds(286, 123, 100, 29);
		contentPane.add(btnHsm);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(61, 21, 280, 75);
		BufferedImage myPicture = ImageIO.read(new File("./Imagens/tu2.jpg"));	

		lblNewLabel.setIcon(new ImageIcon(myPicture));
		contentPane.add(lblNewLabel);
	}
}
