package Objects;

public class MReport {

	private String report;

	public MReport(String report) {
		this.report = report;
	}

	public String getReport() {
		return report;
	}

	public void setReport(String report) {
		this.report = report;
	}
}
