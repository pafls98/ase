package Objects;

import java.io.Serializable;

public class Search implements Serializable {
	
	private static final long serialVersionUID = -3689564910125552997L;
	private int id;
	private String name;
	private boolean cS;
	private boolean pat;	
	private boolean Consultation;
	private boolean record;
	
	public boolean isRecord() {
		return record;
	}

	public void setRecord(boolean record) {
		this.record = record;
	}

	public Search(int id) {
		this.id = id;
	}
	
	public Search(String name, boolean cS) {
		this.setName(name);
		this.setcS(cS);
	}

	public boolean isPat() {
		return pat;
	}

	public void setPat(boolean pat) {
		this.pat = pat;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean iscS() {
		return cS;
	}

	public void setcS(boolean cS) {
		this.cS = cS;
	}

	public boolean isConsultation() {
		return Consultation;
	}

	public void setConsultation(boolean consultation) {
		Consultation = consultation;
	}
	
	
	

}
