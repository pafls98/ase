package Objects;

import java.io.Serializable;

import Clients.ClinicalStaff;

public class SearchResponse implements Serializable{

	
	private static final long serialVersionUID = 7650952864080730743L;
	
	private String date;
	private Drug d;
	private Treatment t;
	private String c;
	private ClinicalStaff cs;
	private boolean updated;
	private String patient;
	private Patient p ;
	private boolean consultation;
	private boolean search;
	private boolean attended;
	private String b;
	private int id;
	private String hours;
	private String cs2;
	private boolean record;
	
	public SearchResponse(String date, Drug d, Treatment t, String c, ClinicalStaff cs, boolean updated,String patient) {
		this.patient=patient;
		this.date = date;
		this.d = d;
		this.t = t;
		this.c = c;
		this.cs = cs;
		this.updated = updated;
	}
	public SearchResponse(String patient,boolean attended, String date, String b, String cs,int id,String hours) {
		this.patient=patient;
		this.setAttended(attended);
		this.date=date;
		this.setB(b);
		this.setCs2(cs);
		this.setId(id);
		this.setHours(hours);
	}
	public SearchResponse(Patient p) {
		this.setP(p);
	}
	@Override
	public String toString() {
		return getPatient() + " : " + getDate() + " : " + getCs().getNAME() + " : " + getC() + " : " + getT().getName() + " : " +  getD().getName() + " : " + "Updated"+ " : " + getId();
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Drug getD() {
		return d;
	}
	public void setD(Drug d) {
		this.d = d;
	}
	public Treatment getT() {
		return t;
	}
	public void setT(Treatment t) {
		this.t = t;
	}
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	public ClinicalStaff getCs() {
		return cs;
	}
	public void setCs(ClinicalStaff cs) {
		this.cs = cs;
	}
	public boolean isUpdated() {
		return updated;
	}
	public void setUpdated(boolean updated) {
		this.updated = updated;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getPatient() {
		return patient;
	}
	public boolean isAttended() {
		return attended;
	}
	public void setAttended(boolean attended) {
		this.attended = attended;
	}
	public String getB() {
		return b;
	}
	public void setB(String b) {
		this.b = b;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHours() {
		return hours;
	}
	public void setHours(String hours) {
		this.hours = hours;
	}
	public String getCs2() {
		return cs2;
	}
	public void setCs2(String cs2) {
		this.cs2 = cs2;
	}
	public boolean isConsultation() {
		return consultation;
	}
	public void setConsultation(boolean consultation) {
		this.consultation = consultation;
	}
	public Patient getP() {
		return p;
	}
	public void setP(Patient p) {
		this.p = p;
	}
	public boolean isSearch() {
		return search;
	}
	public void setSearch(boolean search) {
		this.search = search;
	}
	public void setRecord(boolean e) {
		this.record=e;
		
	}
	public boolean isRecord() {
		return record;
	}
}
