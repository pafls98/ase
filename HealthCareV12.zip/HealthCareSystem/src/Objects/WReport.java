package Objects;

import java.io.Serializable;

public class WReport implements Serializable{


	private static final long serialVersionUID = 695288170699348922L;
	private String d;
	private String c;
	private int np;


	public WReport(String c,String d,int np) {
		this.d=d;
		this.c = c;
		this.np=np;
	}

	public String getReport() {
		return c;
	}

	public void setReport(String report) {
		this.c = report;
	}

	public String getD() {
		return d;
	}

	public void setD(String d) {
		this.d = d;
	}

	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public int getNp() {
		return np;
	}

	public void setNp(int np) {
		this.np = np;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
