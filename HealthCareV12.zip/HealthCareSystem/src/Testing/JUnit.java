package Testing;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import Clients.Receptionist;
import GUI.RGUI;
import Server.Server;

public class JUnit {

	@Test
	public void ServerInfoDrugs() {
		Server s = new Server(8080);
		s.getDrugsList();
	}

	@Test
	public void ServerInfoBuildings() {
		Server s = new Server(8080);
		s.getBuildingsList();
	}

	@Test
	public void ServerPatients() {
		Server s = new Server(8080);
		s.getPatientsList();
	}

	@Test
	public void ServerClinicalStaff() {
		Server s = new Server(8080);
		s.getClinicalStaffList();
	}
	@Test
	public void GUI() {
		Receptionist r = new Receptionist(1, "Joanna", "localhost", 8080);
		RGUI rgui = new RGUI(r);
	}
}
